import './App.css';
import Home from './Components/screens/Home';
import { Route, Routes } from 'react-router-dom';
import Login from './Components/screens/Login';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import Signup from './Components/screens/Signup';

export default function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path='/signup' element={<Signup/>}/>
      </Routes>
    </div>
  );
}