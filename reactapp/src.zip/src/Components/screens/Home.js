import React from 'react'
import Navbar from '../Navbar'
import Footer from '../Footer'
import Cards from '../Cards';
import Carousal from '../Carousal';

function Home() {
  return (
    <div>
      <div><Navbar /></div>
      <div> <Carousal /></div>
      <div className='m-3'id="card1">
        <Cards />
        
        </div>

      <div><Footer /></div>
    </div>
  )
}

export default Home;
