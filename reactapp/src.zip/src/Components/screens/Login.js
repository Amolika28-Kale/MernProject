import React, { useState } from 'react'
import { Link } from 'react-router-dom';

export default function Login() {

  var [first, setFirst] = useState({ email: "", password: "" });

  var handleSubmit = async (event) => {
    event.preventDefault();
    var response = await fetch("http://localhost:3000/signup ", {
      method: "POST",
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify()
    });
    var result = await response.json();
    console.log(result);
  }

  var onChange = (event) => {
    setFirst({ ...first, [event.target.name]: event.target.value })
  }

  
  return (
    <>

      <div className='container'>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">Name</label>
            <input type="text" className="form-control" name='name' value={first.name} onChange={onChange} />
          </div>

          <div className="mb-3">
            <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
            <input type="password" className="form-control" name='password' value={first.password} onChange={onChange} />
          </div>
          <button type="submit" className="btn btn-primary">Submit</button>

          <Link to="/signup" className='m-3 btn btn-danger'>I am a new User</Link>

        </form>
      </div>

    </>
  )
}
